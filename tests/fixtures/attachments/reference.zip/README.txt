Synthetic attachment fixture. No business or personal data.
